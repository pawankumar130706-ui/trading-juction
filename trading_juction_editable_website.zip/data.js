// YAHI FILE UPDATE KARNA HAI
// Apna channel link, email, Instagram, videos aur notes yahan change karo.

const siteData = {
  siteName: "Trading Juction",
  tagline: "Learn • Trade • Grow",
  founderName: "Pawan Kumar",
  youtubeLink: "https://youtube.com/@yourchannel",
  email: "yourmail@example.com",
  instagram: "@yourhandle",
  telegram: "@yourchannel",
  subscribers: "10K+",
  videosCount: "500+",

  videos: [
    {
      title: "Perfect Entry Strategy",
      description: "Entry lene se pehle support, resistance aur trend kaise check karein.",
      link: "#"
    },
    {
      title: "Profit Booking Kaise Kare",
      description: "Profit kab book karna chahiye aur greed se kaise bachein.",
      link: "#"
    },
    {
      title: "90% Traders Ki Galti",
      description: "Overtrading, no stop-loss aur emotional trading se bachne ka tarika.",
      link: "#"
    },
    {
      title: "Risk Management Rules",
      description: "Capital bachane ke simple aur powerful rules.",
      link: "#"
    }
  ],

  notes: [
    {
      title: "Trading Basics PDF",
      description: "Beginners ke liye stock market basics.",
      link: "#"
    },
    {
      title: "Candlestick Notes",
      description: "Common candle patterns aur unka meaning.",
      link: "#"
    },
    {
      title: "Risk Management Sheet",
      description: "Stop loss aur position sizing ka basic plan.",
      link: "#"
    }
  ]
};
